databases = {
    'db': {
        'host': '127.0.0.1',
        'port': 3306,
        'dbname': 'mytest',
        'user': 'root',
        'password': 'lin123456*',
        'charset': 'utf8mb4'
    }
}
